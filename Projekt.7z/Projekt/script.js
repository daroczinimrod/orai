function myFunction() {
    document.getElementById("kep").src = document.getElementById("cars").value;
    document.getElementById("kep").style.height = document.getElementById("Height").value;
    document.getElementById("kep").style.width = document.getElementById("Width").value;
}

function Blur() {

    if (document.getElementById("Blur").checked) 
    {
        document.getElementById("kep").style.filter = "blur(5px)";
    }

    else
    {
        document.getElementById("kep").style.filter = "blur(0px)";
    }

}

function Invert() {

    if (document.getElementById("Invert").checked)
    {
        document.getElementById("kep").style.filter = "invert(100%)";
    }
    else 
    { 
        document.getElementById("kep").style.filter = "invert(0%)"; 
    }


}